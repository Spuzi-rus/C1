﻿namespace Mebelnaya_Fabrika
{
    partial class Avtorizatsiya
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Avtorizatsiya));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Metka_Avtorizatsiya = new System.Windows.Forms.Label();
            this.tbLogin = new System.Windows.Forms.TextBox();
            this.tbParol = new System.Windows.Forms.TextBox();
            this.Metka_Login = new System.Windows.Forms.Label();
            this.Metka_Parol = new System.Windows.Forms.Label();
            this.Avtorizatsiya_Vhod = new System.Windows.Forms.Button();
            this.cbRol = new System.Windows.Forms.ComboBox();
            this.Metka_Rol = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(110, 110);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Metka_Avtorizatsiya
            // 
            this.Metka_Avtorizatsiya.AutoSize = true;
            this.Metka_Avtorizatsiya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Metka_Avtorizatsiya.Location = new System.Drawing.Point(380, 150);
            this.Metka_Avtorizatsiya.Name = "Metka_Avtorizatsiya";
            this.Metka_Avtorizatsiya.Size = new System.Drawing.Size(258, 29);
            this.Metka_Avtorizatsiya.TabIndex = 2;
            this.Metka_Avtorizatsiya.Text = "Введите свои данные";
            // 
            // tbLogin
            // 
            this.tbLogin.Location = new System.Drawing.Point(445, 241);
            this.tbLogin.Name = "tbLogin";
            this.tbLogin.Size = new System.Drawing.Size(193, 28);
            this.tbLogin.TabIndex = 3;
            // 
            // tbParol
            // 
            this.tbParol.Location = new System.Drawing.Point(445, 298);
            this.tbParol.Name = "tbParol";
            this.tbParol.Size = new System.Drawing.Size(193, 28);
            this.tbParol.TabIndex = 4;
            // 
            // Metka_Login
            // 
            this.Metka_Login.AutoSize = true;
            this.Metka_Login.Location = new System.Drawing.Point(374, 244);
            this.Metka_Login.Name = "Metka_Login";
            this.Metka_Login.Size = new System.Drawing.Size(65, 22);
            this.Metka_Login.TabIndex = 5;
            this.Metka_Login.Text = "Логин:";
            // 
            // Metka_Parol
            // 
            this.Metka_Parol.AutoSize = true;
            this.Metka_Parol.Location = new System.Drawing.Point(362, 301);
            this.Metka_Parol.Name = "Metka_Parol";
            this.Metka_Parol.Size = new System.Drawing.Size(77, 22);
            this.Metka_Parol.TabIndex = 6;
            this.Metka_Parol.Text = "Пароль:";
            // 
            // Avtorizatsiya_Vhod
            // 
            this.Avtorizatsiya_Vhod.Location = new System.Drawing.Point(455, 415);
            this.Avtorizatsiya_Vhod.Name = "Avtorizatsiya_Vhod";
            this.Avtorizatsiya_Vhod.Size = new System.Drawing.Size(127, 54);
            this.Avtorizatsiya_Vhod.TabIndex = 7;
            this.Avtorizatsiya_Vhod.Text = "Вход";
            this.Avtorizatsiya_Vhod.UseVisualStyleBackColor = true;
            this.Avtorizatsiya_Vhod.Click += new System.EventHandler(this.Avtorizatsiya_Vhod_Click);
            // 
            // cbRol
            // 
            this.cbRol.FormattingEnabled = true;
            this.cbRol.Items.AddRange(new object[] {
            "Менеджер",
            "Заместитель директора",
            "Заказчик",
            "Директор",
            "Мастер"});
            this.cbRol.Location = new System.Drawing.Point(445, 357);
            this.cbRol.Name = "cbRol";
            this.cbRol.Size = new System.Drawing.Size(193, 30);
            this.cbRol.TabIndex = 8;
            // 
            // Metka_Rol
            // 
            this.Metka_Rol.AutoSize = true;
            this.Metka_Rol.Location = new System.Drawing.Point(383, 360);
            this.Metka_Rol.Name = "Metka_Rol";
            this.Metka_Rol.Size = new System.Drawing.Size(56, 22);
            this.Metka_Rol.TabIndex = 9;
            this.Metka_Rol.Text = "Роль:";
            // 
            // Avtorizatsiya
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 619);
            this.Controls.Add(this.Metka_Rol);
            this.Controls.Add(this.cbRol);
            this.Controls.Add(this.Avtorizatsiya_Vhod);
            this.Controls.Add(this.Metka_Parol);
            this.Controls.Add(this.Metka_Login);
            this.Controls.Add(this.tbParol);
            this.Controls.Add(this.tbLogin);
            this.Controls.Add(this.Metka_Avtorizatsiya);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Avtorizatsiya";
            this.Text = "Avtorizatsiya";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Metka_Avtorizatsiya;
        private System.Windows.Forms.TextBox tbLogin;
        private System.Windows.Forms.TextBox tbParol;
        private System.Windows.Forms.Label Metka_Login;
        private System.Windows.Forms.Label Metka_Parol;
        private System.Windows.Forms.Button Avtorizatsiya_Vhod;
        private System.Windows.Forms.ComboBox cbRol;
        private System.Windows.Forms.Label Metka_Rol;
    }
}
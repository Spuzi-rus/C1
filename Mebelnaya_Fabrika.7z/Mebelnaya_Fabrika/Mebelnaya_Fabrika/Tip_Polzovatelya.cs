﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mebelnaya_Fabrika
{
    internal class Tip_Polzovatelya
    {
        internal static string Rol;
    }
}

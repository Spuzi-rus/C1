﻿namespace Mebelnaya_Fabrika
{
    partial class Menyu
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menyu));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Metka_Mebelnaya_Fabrika = new System.Windows.Forms.Label();
            this.Menyu_Dalee = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(110, 110);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Metka_Mebelnaya_Fabrika
            // 
            this.Metka_Mebelnaya_Fabrika.AutoSize = true;
            this.Metka_Mebelnaya_Fabrika.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Metka_Mebelnaya_Fabrika.Location = new System.Drawing.Point(377, 93);
            this.Metka_Mebelnaya_Fabrika.Name = "Metka_Mebelnaya_Fabrika";
            this.Metka_Mebelnaya_Fabrika.Size = new System.Drawing.Size(247, 29);
            this.Metka_Mebelnaya_Fabrika.TabIndex = 1;
            this.Metka_Mebelnaya_Fabrika.Text = "Мебельная фабрика";
            // 
            // Menyu_Dalee
            // 
            this.Menyu_Dalee.Location = new System.Drawing.Point(428, 336);
            this.Menyu_Dalee.Name = "Menyu_Dalee";
            this.Menyu_Dalee.Size = new System.Drawing.Size(145, 71);
            this.Menyu_Dalee.TabIndex = 2;
            this.Menyu_Dalee.Text = "Далее";
            this.Menyu_Dalee.UseVisualStyleBackColor = true;
            this.Menyu_Dalee.Click += new System.EventHandler(this.Menyu_Dalee_Click);
            // 
            // Menyu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 619);
            this.Controls.Add(this.Menyu_Dalee);
            this.Controls.Add(this.Metka_Mebelnaya_Fabrika);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Menyu";
            this.Text = "Меню";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Metka_Mebelnaya_Fabrika;
        private System.Windows.Forms.Button Menyu_Dalee;
    }
}


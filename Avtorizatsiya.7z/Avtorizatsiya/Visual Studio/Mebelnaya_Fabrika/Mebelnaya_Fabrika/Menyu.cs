﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mebelnaya_Fabrika
{
    public partial class Menyu : Form
    {
        public Menyu()
        {
            InitializeComponent();
        }

        private void Menyu_Dalee_Click(object sender, EventArgs e) // кликнув по кнопке "Далее" происходит переход на форму
        {
            Avtorizatsiya avt = new Avtorizatsiya();
            avt.Show();
            this.Hide();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mebelnaya_Fabrika
{
    public partial class Polzovatel_Master : Form
    {
        public Polzovatel_Master()
        {
            InitializeComponent();
        }
    }
}

﻿
namespace Mebelnaya_Fabrika
{
    partial class Avtorizatsiya
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Avtorizatsiya));
            this.Metka_Login = new System.Windows.Forms.Label();
            this.Metka_Parol = new System.Windows.Forms.Label();
            this.tbLogin = new System.Windows.Forms.TextBox();
            this.tbParol = new System.Windows.Forms.TextBox();
            this.Metka_Vvod_Dannyh = new System.Windows.Forms.Label();
            this.cbRol = new System.Windows.Forms.ComboBox();
            this.Metka_Rol = new System.Windows.Forms.Label();
            this.Avtorizatsiya_Vhod = new System.Windows.Forms.Button();
            this.Panel = new System.Windows.Forms.Panel();
            this.Metka_Avtorizatsiya = new System.Windows.Forms.Label();
            this.Logotip = new System.Windows.Forms.PictureBox();
            this.Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logotip)).BeginInit();
            this.SuspendLayout();
            // 
            // Metka_Login
            // 
            this.Metka_Login.AutoSize = true;
            this.Metka_Login.Location = new System.Drawing.Point(249, 197);
            this.Metka_Login.Name = "Metka_Login";
            this.Metka_Login.Size = new System.Drawing.Size(54, 18);
            this.Metka_Login.TabIndex = 2;
            this.Metka_Login.Text = "Логин:";
            // 
            // Metka_Parol
            // 
            this.Metka_Parol.AutoSize = true;
            this.Metka_Parol.Location = new System.Drawing.Point(238, 247);
            this.Metka_Parol.Name = "Metka_Parol";
            this.Metka_Parol.Size = new System.Drawing.Size(65, 18);
            this.Metka_Parol.TabIndex = 3;
            this.Metka_Parol.Text = "Пароль:";
            // 
            // tbLogin
            // 
            this.tbLogin.Location = new System.Drawing.Point(309, 194);
            this.tbLogin.Name = "tbLogin";
            this.tbLogin.Size = new System.Drawing.Size(207, 24);
            this.tbLogin.TabIndex = 4;
            // 
            // tbParol
            // 
            this.tbParol.Location = new System.Drawing.Point(309, 244);
            this.tbParol.Name = "tbParol";
            this.tbParol.PasswordChar = '*';
            this.tbParol.Size = new System.Drawing.Size(207, 24);
            this.tbParol.TabIndex = 5;
            // 
            // Metka_Vvod_Dannyh
            // 
            this.Metka_Vvod_Dannyh.AutoSize = true;
            this.Metka_Vvod_Dannyh.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Metka_Vvod_Dannyh.Location = new System.Drawing.Point(288, 152);
            this.Metka_Vvod_Dannyh.Name = "Metka_Vvod_Dannyh";
            this.Metka_Vvod_Dannyh.Size = new System.Drawing.Size(178, 18);
            this.Metka_Vvod_Dannyh.TabIndex = 6;
            this.Metka_Vvod_Dannyh.Text = "Введите свои данные";
            // 
            // cbRol
            // 
            this.cbRol.FormattingEnabled = true;
            this.cbRol.Items.AddRange(new object[] {
            "Менеджер",
            "Заместитель директора",
            "Заказчик",
            "Директор",
            "Мастер"});
            this.cbRol.Location = new System.Drawing.Point(309, 288);
            this.cbRol.Name = "cbRol";
            this.cbRol.Size = new System.Drawing.Size(207, 26);
            this.cbRol.TabIndex = 7;
            // 
            // Metka_Rol
            // 
            this.Metka_Rol.AutoSize = true;
            this.Metka_Rol.Location = new System.Drawing.Point(255, 291);
            this.Metka_Rol.Name = "Metka_Rol";
            this.Metka_Rol.Size = new System.Drawing.Size(48, 18);
            this.Metka_Rol.TabIndex = 8;
            this.Metka_Rol.Text = "Роль:";
            // 
            // Avtorizatsiya_Vhod
            // 
            this.Avtorizatsiya_Vhod.Location = new System.Drawing.Point(325, 351);
            this.Avtorizatsiya_Vhod.Name = "Avtorizatsiya_Vhod";
            this.Avtorizatsiya_Vhod.Size = new System.Drawing.Size(104, 52);
            this.Avtorizatsiya_Vhod.TabIndex = 9;
            this.Avtorizatsiya_Vhod.Text = "Вход";
            this.Avtorizatsiya_Vhod.UseVisualStyleBackColor = true;
            this.Avtorizatsiya_Vhod.Click += new System.EventHandler(this.Avtorizatsiya_Vhod_Click);
            // 
            // Panel
            // 
            this.Panel.BackColor = System.Drawing.SystemColors.GrayText;
            this.Panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel.Controls.Add(this.Metka_Avtorizatsiya);
            this.Panel.Controls.Add(this.Logotip);
            this.Panel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Panel.ForeColor = System.Drawing.SystemColors.Control;
            this.Panel.Location = new System.Drawing.Point(12, 12);
            this.Panel.Name = "Panel";
            this.Panel.Size = new System.Drawing.Size(730, 117);
            this.Panel.TabIndex = 10;
            // 
            // Metka_Avtorizatsiya
            // 
            this.Metka_Avtorizatsiya.AutoSize = true;
            this.Metka_Avtorizatsiya.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Metka_Avtorizatsiya.Location = new System.Drawing.Point(294, 45);
            this.Metka_Avtorizatsiya.Name = "Metka_Avtorizatsiya";
            this.Metka_Avtorizatsiya.Size = new System.Drawing.Size(140, 24);
            this.Metka_Avtorizatsiya.TabIndex = 1;
            this.Metka_Avtorizatsiya.Text = "Авторизация";
            // 
            // Logotip
            // 
            this.Logotip.Image = ((System.Drawing.Image)(resources.GetObject("Logotip.Image")));
            this.Logotip.Location = new System.Drawing.Point(3, 3);
            this.Logotip.Name = "Logotip";
            this.Logotip.Size = new System.Drawing.Size(110, 110);
            this.Logotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Logotip.TabIndex = 0;
            this.Logotip.TabStop = false;
            // 
            // Avtorizatsiya
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 463);
            this.Controls.Add(this.Panel);
            this.Controls.Add(this.Avtorizatsiya_Vhod);
            this.Controls.Add(this.Metka_Rol);
            this.Controls.Add(this.cbRol);
            this.Controls.Add(this.Metka_Vvod_Dannyh);
            this.Controls.Add(this.tbParol);
            this.Controls.Add(this.tbLogin);
            this.Controls.Add(this.Metka_Parol);
            this.Controls.Add(this.Metka_Login);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Avtorizatsiya";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Авторизация";
            this.Panel.ResumeLayout(false);
            this.Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logotip)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label Metka_Login;
        private System.Windows.Forms.Label Metka_Parol;
        private System.Windows.Forms.TextBox tbLogin;
        private System.Windows.Forms.TextBox tbParol;
        private System.Windows.Forms.Label Metka_Vvod_Dannyh;
        private System.Windows.Forms.ComboBox cbRol;
        private System.Windows.Forms.Label Metka_Rol;
        private System.Windows.Forms.Button Avtorizatsiya_Vhod;
        private System.Windows.Forms.Panel Panel;
        private System.Windows.Forms.Label Metka_Avtorizatsiya;
        private System.Windows.Forms.PictureBox Logotip;
    }
}
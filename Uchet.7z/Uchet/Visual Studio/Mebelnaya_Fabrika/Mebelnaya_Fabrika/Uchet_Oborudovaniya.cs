﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mebelnaya_Fabrika
{
    public partial class Uchet_Oborudovaniya : Form
    {
        public Uchet_Oborudovaniya()
        {
            InitializeComponent();
        }

        private void oborudovanieBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.oborudovanieBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.mebelnaya_FabrikaDataSet);

        }

        private void Uchet_Oborudovaniya_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "mebelnaya_FabrikaDataSet.Oborudovanie". При необходимости она может быть перемещена или удалена.
            this.oborudovanieTableAdapter.Fill(this.mebelnaya_FabrikaDataSet.Oborudovanie);

        }

        private void Dobavit_Click(object sender, EventArgs e)
        {
            oborudovanieBindingSource.AddNew();
        }

        private void Udalit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Вы точно хотите удалить запись?", "Предупреждение!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                oborudovanieBindingSource.RemoveCurrent();
                this.Validate();
                this.oborudovanieBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.mebelnaya_FabrikaDataSet);
            }
            else if (dialogResult == DialogResult.No)
            {
                
            }
        }

        private void Sohranit_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.oborudovanieBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.mebelnaya_FabrikaDataSet);
        }

        private void Nazad_Click(object sender, EventArgs e)
        {
            Polzovatel_Direktor pld = new Polzovatel_Direktor();
            pld.Show();
            this.Hide();
        }
    }
}

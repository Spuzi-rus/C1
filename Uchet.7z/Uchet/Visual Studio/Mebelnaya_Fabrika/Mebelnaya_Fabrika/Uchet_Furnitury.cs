﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mebelnaya_Fabrika
{
    public partial class Uchet_Furnitury : Form
    {
        public Uchet_Furnitury()
        {
            InitializeComponent();
        }

        private void furnituraBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.furnituraBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.mebelnaya_FabrikaDataSet);

        }

        private void Uchet_Furnitury_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "mebelnaya_FabrikaDataSet.Furnitura". При необходимости она может быть перемещена или удалена.
            this.furnituraTableAdapter.Fill(this.mebelnaya_FabrikaDataSet.Furnitura);

        }

        private void Sohranit_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.furnituraBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.mebelnaya_FabrikaDataSet);
        }

        private void Udalit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Вы точно хотите удалить запись?", "Предупреждение!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                furnituraBindingSource.RemoveCurrent();
                this.Validate();
                this.furnituraBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.mebelnaya_FabrikaDataSet);
            }
            else if (dialogResult == DialogResult.No)
            {

            }
        }

        private void Nayti_Click(object sender, EventArgs e)
        {
            furnituraBindingSource.Filter = "[Тип] LIKE'" + tbPoisk.Text + "%'";
        }

        private void Otmena_Click(object sender, EventArgs e)
        {
            furnituraBindingSource.Filter = "";
        }

        private void Nazad_Click(object sender, EventArgs e)
        {
            Avtorizatsiya avt = new Avtorizatsiya();
            avt.Show();
            this.Hide();
        }
    }
}

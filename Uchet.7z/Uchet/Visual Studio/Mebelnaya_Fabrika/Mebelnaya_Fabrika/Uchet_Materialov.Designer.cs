﻿
namespace Mebelnaya_Fabrika
{
    partial class Uchet_Materialov
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Uchet_Materialov));
            this.Panel = new System.Windows.Forms.Panel();
            this.Metka_Uchet_Materialov = new System.Windows.Forms.Label();
            this.Logotip = new System.Windows.Forms.PictureBox();
            this.mebelnaya_FabrikaDataSet = new Mebelnaya_Fabrika.Mebelnaya_FabrikaDataSet();
            this.materialyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.materialyTableAdapter = new Mebelnaya_Fabrika.Mebelnaya_FabrikaDataSetTableAdapters.MaterialyTableAdapter();
            this.tableAdapterManager = new Mebelnaya_Fabrika.Mebelnaya_FabrikaDataSetTableAdapters.TableAdapterManager();
            this.materialyDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sohranit = new System.Windows.Forms.Button();
            this.Udalit = new System.Windows.Forms.Button();
            this.tbPoisk = new System.Windows.Forms.TextBox();
            this.Nayti = new System.Windows.Forms.Button();
            this.Metka_Tsena = new System.Windows.Forms.Label();
            this.Otmena = new System.Windows.Forms.Button();
            this.Nazad = new System.Windows.Forms.Button();
            this.Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logotip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mebelnaya_FabrikaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialyDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel
            // 
            this.Panel.BackColor = System.Drawing.SystemColors.GrayText;
            this.Panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel.Controls.Add(this.Metka_Uchet_Materialov);
            this.Panel.Controls.Add(this.Logotip);
            this.Panel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Panel.ForeColor = System.Drawing.SystemColors.Control;
            this.Panel.Location = new System.Drawing.Point(12, 12);
            this.Panel.Name = "Panel";
            this.Panel.Size = new System.Drawing.Size(884, 102);
            this.Panel.TabIndex = 13;
            // 
            // Metka_Uchet_Materialov
            // 
            this.Metka_Uchet_Materialov.AutoSize = true;
            this.Metka_Uchet_Materialov.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Metka_Uchet_Materialov.Location = new System.Drawing.Point(351, 38);
            this.Metka_Uchet_Materialov.Name = "Metka_Uchet_Materialov";
            this.Metka_Uchet_Materialov.Size = new System.Drawing.Size(181, 24);
            this.Metka_Uchet_Materialov.TabIndex = 1;
            this.Metka_Uchet_Materialov.Text = "Учёт материалов";
            // 
            // Logotip
            // 
            this.Logotip.Image = ((System.Drawing.Image)(resources.GetObject("Logotip.Image")));
            this.Logotip.Location = new System.Drawing.Point(3, 3);
            this.Logotip.Name = "Logotip";
            this.Logotip.Size = new System.Drawing.Size(97, 94);
            this.Logotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Logotip.TabIndex = 0;
            this.Logotip.TabStop = false;
            // 
            // mebelnaya_FabrikaDataSet
            // 
            this.mebelnaya_FabrikaDataSet.DataSetName = "Mebelnaya_FabrikaDataSet";
            this.mebelnaya_FabrikaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // materialyBindingSource
            // 
            this.materialyBindingSource.DataMember = "Materialy";
            this.materialyBindingSource.DataSource = this.mebelnaya_FabrikaDataSet;
            // 
            // materialyTableAdapter
            // 
            this.materialyTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.FurnituraTableAdapter = null;
            this.tableAdapterManager.MaterialyTableAdapter = this.materialyTableAdapter;
            this.tableAdapterManager.OborudovanieTableAdapter = null;
            this.tableAdapterManager.PolzovateliTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Mebelnaya_Fabrika.Mebelnaya_FabrikaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // materialyDataGridView
            // 
            this.materialyDataGridView.AutoGenerateColumns = false;
            this.materialyDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.materialyDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.materialyDataGridView.DataSource = this.materialyBindingSource;
            this.materialyDataGridView.Location = new System.Drawing.Point(12, 120);
            this.materialyDataGridView.Name = "materialyDataGridView";
            this.materialyDataGridView.Size = new System.Drawing.Size(884, 220);
            this.materialyDataGridView.TabIndex = 14;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Артикул";
            this.dataGridViewTextBoxColumn1.HeaderText = "Артикул";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "   Наименование";
            this.dataGridViewTextBoxColumn2.HeaderText = "   Наименование";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Единица измерения";
            this.dataGridViewTextBoxColumn3.HeaderText = "Единица измерения";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Длина (м)";
            this.dataGridViewTextBoxColumn4.HeaderText = "Длина (м)";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Количество";
            this.dataGridViewTextBoxColumn5.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Тип материала";
            this.dataGridViewTextBoxColumn6.HeaderText = "Тип материала";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Цена";
            this.dataGridViewTextBoxColumn7.HeaderText = "Цена";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "ГОСТ";
            this.dataGridViewTextBoxColumn8.HeaderText = "ГОСТ";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // Sohranit
            // 
            this.Sohranit.Location = new System.Drawing.Point(704, 346);
            this.Sohranit.Name = "Sohranit";
            this.Sohranit.Size = new System.Drawing.Size(93, 39);
            this.Sohranit.TabIndex = 19;
            this.Sohranit.Text = "Сохранить";
            this.Sohranit.UseVisualStyleBackColor = true;
            this.Sohranit.Click += new System.EventHandler(this.Sohranit_Click);
            // 
            // Udalit
            // 
            this.Udalit.Location = new System.Drawing.Point(803, 346);
            this.Udalit.Name = "Udalit";
            this.Udalit.Size = new System.Drawing.Size(93, 39);
            this.Udalit.TabIndex = 18;
            this.Udalit.Text = "Удалить";
            this.Udalit.UseVisualStyleBackColor = true;
            this.Udalit.Click += new System.EventHandler(this.Udalit_Click);
            // 
            // tbPoisk
            // 
            this.tbPoisk.Location = new System.Drawing.Point(62, 353);
            this.tbPoisk.Name = "tbPoisk";
            this.tbPoisk.Size = new System.Drawing.Size(211, 24);
            this.tbPoisk.TabIndex = 20;
            // 
            // Nayti
            // 
            this.Nayti.Location = new System.Drawing.Point(279, 346);
            this.Nayti.Name = "Nayti";
            this.Nayti.Size = new System.Drawing.Size(93, 39);
            this.Nayti.TabIndex = 21;
            this.Nayti.Text = "Найти";
            this.Nayti.UseVisualStyleBackColor = true;
            this.Nayti.Click += new System.EventHandler(this.Nayti_Click);
            // 
            // Metka_Tsena
            // 
            this.Metka_Tsena.AutoSize = true;
            this.Metka_Tsena.Location = new System.Drawing.Point(9, 356);
            this.Metka_Tsena.Name = "Metka_Tsena";
            this.Metka_Tsena.Size = new System.Drawing.Size(47, 18);
            this.Metka_Tsena.TabIndex = 22;
            this.Metka_Tsena.Text = "Цена:";
            // 
            // Otmena
            // 
            this.Otmena.Location = new System.Drawing.Point(378, 346);
            this.Otmena.Name = "Otmena";
            this.Otmena.Size = new System.Drawing.Size(93, 39);
            this.Otmena.TabIndex = 23;
            this.Otmena.Text = "Отмена";
            this.Otmena.UseVisualStyleBackColor = true;
            this.Otmena.Click += new System.EventHandler(this.Otmena_Click);
            // 
            // Nazad
            // 
            this.Nazad.Location = new System.Drawing.Point(12, 440);
            this.Nazad.Name = "Nazad";
            this.Nazad.Size = new System.Drawing.Size(93, 39);
            this.Nazad.TabIndex = 24;
            this.Nazad.Text = "Назад";
            this.Nazad.UseVisualStyleBackColor = true;
            this.Nazad.Click += new System.EventHandler(this.Nazad_Click);
            // 
            // Uchet_Materialov
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(908, 491);
            this.Controls.Add(this.Nazad);
            this.Controls.Add(this.Otmena);
            this.Controls.Add(this.Metka_Tsena);
            this.Controls.Add(this.Nayti);
            this.Controls.Add(this.tbPoisk);
            this.Controls.Add(this.Sohranit);
            this.Controls.Add(this.Udalit);
            this.Controls.Add(this.materialyDataGridView);
            this.Controls.Add(this.Panel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Uchet_Materialov";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Учёт материалов";
            this.Load += new System.EventHandler(this.Uchet_Materialov_Load);
            this.Panel.ResumeLayout(false);
            this.Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logotip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mebelnaya_FabrikaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialyDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel Panel;
        private System.Windows.Forms.Label Metka_Uchet_Materialov;
        private System.Windows.Forms.PictureBox Logotip;
        private Mebelnaya_FabrikaDataSet mebelnaya_FabrikaDataSet;
        private System.Windows.Forms.BindingSource materialyBindingSource;
        private Mebelnaya_FabrikaDataSetTableAdapters.MaterialyTableAdapter materialyTableAdapter;
        private Mebelnaya_FabrikaDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView materialyDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.Button Sohranit;
        private System.Windows.Forms.Button Udalit;
        private System.Windows.Forms.TextBox tbPoisk;
        private System.Windows.Forms.Button Nayti;
        private System.Windows.Forms.Label Metka_Tsena;
        private System.Windows.Forms.Button Otmena;
        private System.Windows.Forms.Button Nazad;
    }
}
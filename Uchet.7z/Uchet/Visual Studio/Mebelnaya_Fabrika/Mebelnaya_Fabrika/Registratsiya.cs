﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Mebelnaya_Fabrika
{
    public partial class Registratsiya : Form
    {
        public Registratsiya()
        {
            InitializeComponent();
        }

        private void Registratsiya_Registratsiya_Click(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection(@"Data Source=SPUZI\SQLEXPRESS;Initial Catalog=Mebelnaya_Fabrika;Integrated Security=True");
            SqlCommand command = new SqlCommand("Insert into Polzovateli values(@Фамилия, @Имя, @Отчество, @Логин, @Пароль, @Роль)", sqlcon);
            command.Parameters.AddWithValue("@Фамилия", tbFamiliya.Text);
            command.Parameters.AddWithValue("@Имя", tbImya.Text);
            command.Parameters.AddWithValue("@Отчество", tbOtchestvo.Text);
            command.Parameters.AddWithValue("@Логин", tbLogin.Text);
            command.Parameters.AddWithValue("@Пароль", tbParol.Text);
            command.Parameters.AddWithValue("@Роль", tbRol.Text);
            command.Connection.Open();
            command.ExecuteNonQuery();
            MessageBox.Show("Аккаунт успешно создан!");
        }

        private void Ssylka_Avtorizatsiya_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Avtorizatsiya avt = new Avtorizatsiya();
            avt.Show();
            this.Hide();
        }
    }
}

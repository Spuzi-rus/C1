﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Mebelnaya_Fabrika
{
    public partial class Avtorizatsiya : Form
    {
        public Avtorizatsiya()
        {
            InitializeComponent();
        }

        private void Avtorizatsiya_Vhod_Click(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection(@"Data Source=SPUZI\SQLEXPRESS;Initial Catalog=Mebelnaya_Fabrika;Integrated Security=True"); //Создание подключения к базе данных
            string query = "Select * from Polzovateli where Логин ='" + tbLogin.Text.Trim() + "' and Пароль = '" + tbParol.Text.Trim() + "' and Роль = '"+cbRol.Text.Trim()+"'"; //отбор данных из столбцов
            SqlDataAdapter sda = new SqlDataAdapter(query, sqlcon);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            if (dtbl.Rows.Count == 1)
            {
                if(cbRol.Text == "Менеджер") //Если выбрана роль "Менеджер" то открывает соответственную форму для этой роли
                {
                    Polzovatel_Menedjer pm = new Polzovatel_Menedjer();
                    pm.Show();
                    this.Hide();
                }
                if (cbRol.Text == "Заместитель директора") //Если выбрана роль "Заместитель директора" то открывает соответственную форму для этой роли
                {
                    Polzovatel_Zam_Direktor pzd = new Polzovatel_Zam_Direktor();
                    pzd.Show();
                    this.Hide();
                }
                if (cbRol.Text == "Заказчик") //Если выбрана роль "Заказчик" то открывает соответственную форму для этой роли
                {
                    Polzovatel_Zakazchik pz = new Polzovatel_Zakazchik();
                    pz.Show();
                    this.Hide();
                }
                if (cbRol.Text == "Директор") //Если выбрана роль "Директор" то открывает соответственную форму для этой роли
                {
                    Polzovatel_Direktor pd = new Polzovatel_Direktor();
                    pd.Show();
                    this.Hide();
                }
                if (cbRol.Text == "Мастер") //Если выбрана роль "Мастер" то открывает соответственную форму для этой роли
                {
                    Polzovatel_Master pm = new Polzovatel_Master();
                    pm.Show();
                    this.Hide();
                }

            }
            else // Если данные введены не верно - выводит ошибку на экран
            {
                MessageBox.Show("Неправильно введены данные");
                tbLogin.Clear();
                tbParol.Clear();
            }
        }

        private void Ssylka_Registratsiya_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Registratsiya reg = new Registratsiya();
            reg.Show();
            this.Hide();
        }

        private void Nazad_Click(object sender, EventArgs e)
        {
            Menyu menyu = new Menyu();
            menyu.Show();
            this.Hide();
        }
    }
}

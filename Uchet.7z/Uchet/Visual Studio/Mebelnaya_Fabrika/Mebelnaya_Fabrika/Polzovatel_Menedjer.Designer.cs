﻿
namespace Mebelnaya_Fabrika
{
    partial class Polzovatel_Menedjer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Polzovatel_Menedjer));
            this.Panel = new System.Windows.Forms.Panel();
            this.Metka_Menedjer = new System.Windows.Forms.Label();
            this.Logotip = new System.Windows.Forms.PictureBox();
            this.Uchet_Furnitury = new System.Windows.Forms.Button();
            this.Uchet_Materialov = new System.Windows.Forms.Button();
            this.Nazad = new System.Windows.Forms.Button();
            this.Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logotip)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel
            // 
            this.Panel.BackColor = System.Drawing.SystemColors.GrayText;
            this.Panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel.Controls.Add(this.Metka_Menedjer);
            this.Panel.Controls.Add(this.Logotip);
            this.Panel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Panel.ForeColor = System.Drawing.SystemColors.Control;
            this.Panel.Location = new System.Drawing.Point(12, 12);
            this.Panel.Name = "Panel";
            this.Panel.Size = new System.Drawing.Size(730, 102);
            this.Panel.TabIndex = 13;
            // 
            // Metka_Menedjer
            // 
            this.Metka_Menedjer.AutoSize = true;
            this.Metka_Menedjer.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Metka_Menedjer.Location = new System.Drawing.Point(307, 38);
            this.Metka_Menedjer.Name = "Metka_Menedjer";
            this.Metka_Menedjer.Size = new System.Drawing.Size(115, 24);
            this.Metka_Menedjer.TabIndex = 1;
            this.Metka_Menedjer.Text = "Менеджер";
            // 
            // Logotip
            // 
            this.Logotip.Image = ((System.Drawing.Image)(resources.GetObject("Logotip.Image")));
            this.Logotip.Location = new System.Drawing.Point(3, 3);
            this.Logotip.Name = "Logotip";
            this.Logotip.Size = new System.Drawing.Size(97, 94);
            this.Logotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Logotip.TabIndex = 0;
            this.Logotip.TabStop = false;
            // 
            // Uchet_Furnitury
            // 
            this.Uchet_Furnitury.Location = new System.Drawing.Point(380, 205);
            this.Uchet_Furnitury.Name = "Uchet_Furnitury";
            this.Uchet_Furnitury.Size = new System.Drawing.Size(156, 52);
            this.Uchet_Furnitury.TabIndex = 25;
            this.Uchet_Furnitury.Text = "Учёт фурнитуры";
            this.Uchet_Furnitury.UseVisualStyleBackColor = true;
            this.Uchet_Furnitury.Click += new System.EventHandler(this.Uchet_Furnitury_Click);
            // 
            // Uchet_Materialov
            // 
            this.Uchet_Materialov.Location = new System.Drawing.Point(218, 205);
            this.Uchet_Materialov.Name = "Uchet_Materialov";
            this.Uchet_Materialov.Size = new System.Drawing.Size(156, 52);
            this.Uchet_Materialov.TabIndex = 24;
            this.Uchet_Materialov.Text = "Учёт материалов";
            this.Uchet_Materialov.UseVisualStyleBackColor = true;
            this.Uchet_Materialov.Click += new System.EventHandler(this.Uchet_Materialov_Click);
            // 
            // Nazad
            // 
            this.Nazad.Location = new System.Drawing.Point(12, 412);
            this.Nazad.Name = "Nazad";
            this.Nazad.Size = new System.Drawing.Size(93, 39);
            this.Nazad.TabIndex = 26;
            this.Nazad.Text = "Назад";
            this.Nazad.UseVisualStyleBackColor = true;
            this.Nazad.Click += new System.EventHandler(this.Nazad_Click);
            // 
            // Polzovatel_Menedjer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 463);
            this.Controls.Add(this.Nazad);
            this.Controls.Add(this.Uchet_Furnitury);
            this.Controls.Add(this.Uchet_Materialov);
            this.Controls.Add(this.Panel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Polzovatel_Menedjer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Пользователь - менеджер";
            this.Panel.ResumeLayout(false);
            this.Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logotip)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Panel;
        private System.Windows.Forms.Label Metka_Menedjer;
        private System.Windows.Forms.PictureBox Logotip;
        private System.Windows.Forms.Button Uchet_Furnitury;
        private System.Windows.Forms.Button Uchet_Materialov;
        private System.Windows.Forms.Button Nazad;
    }
}
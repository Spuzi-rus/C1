﻿
namespace Mebelnaya_Fabrika
{
    partial class Polzovatel_Zakazchik
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Polzovatel_Zakazchik));
            this.Panel = new System.Windows.Forms.Panel();
            this.Metka_Zakazchik = new System.Windows.Forms.Label();
            this.Logotip = new System.Windows.Forms.PictureBox();
            this.Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logotip)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel
            // 
            this.Panel.BackColor = System.Drawing.SystemColors.GrayText;
            this.Panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel.Controls.Add(this.Metka_Zakazchik);
            this.Panel.Controls.Add(this.Logotip);
            this.Panel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Panel.ForeColor = System.Drawing.SystemColors.Control;
            this.Panel.Location = new System.Drawing.Point(12, 12);
            this.Panel.Name = "Panel";
            this.Panel.Size = new System.Drawing.Size(730, 102);
            this.Panel.TabIndex = 13;
            // 
            // Metka_Zakazchik
            // 
            this.Metka_Zakazchik.AutoSize = true;
            this.Metka_Zakazchik.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Metka_Zakazchik.Location = new System.Drawing.Point(314, 38);
            this.Metka_Zakazchik.Name = "Metka_Zakazchik";
            this.Metka_Zakazchik.Size = new System.Drawing.Size(100, 24);
            this.Metka_Zakazchik.TabIndex = 1;
            this.Metka_Zakazchik.Text = "Заказчик";
            // 
            // Logotip
            // 
            this.Logotip.Image = ((System.Drawing.Image)(resources.GetObject("Logotip.Image")));
            this.Logotip.Location = new System.Drawing.Point(3, 3);
            this.Logotip.Name = "Logotip";
            this.Logotip.Size = new System.Drawing.Size(97, 94);
            this.Logotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Logotip.TabIndex = 0;
            this.Logotip.TabStop = false;
            // 
            // Polzovatel_Zakazchik
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 463);
            this.Controls.Add(this.Panel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Polzovatel_Zakazchik";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Пользователь - заказчик";
            this.Panel.ResumeLayout(false);
            this.Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logotip)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Panel;
        private System.Windows.Forms.Label Metka_Zakazchik;
        private System.Windows.Forms.PictureBox Logotip;
    }
}
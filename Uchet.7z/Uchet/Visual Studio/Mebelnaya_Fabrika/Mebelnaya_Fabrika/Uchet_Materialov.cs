﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mebelnaya_Fabrika
{
    public partial class Uchet_Materialov : Form
    {
        public Uchet_Materialov()
        {
            InitializeComponent();
        }

        private void materialyBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.materialyBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.mebelnaya_FabrikaDataSet);

        }

        private void Uchet_Materialov_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "mebelnaya_FabrikaDataSet.Materialy". При необходимости она может быть перемещена или удалена.
            this.materialyTableAdapter.Fill(this.mebelnaya_FabrikaDataSet.Materialy);

        }

        private void Sohranit_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.materialyBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.mebelnaya_FabrikaDataSet);
        }

        private void Udalit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Вы точно хотите удалить запись?", "Предупреждение!", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                materialyBindingSource.RemoveCurrent();
                this.Validate();
                this.materialyBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.mebelnaya_FabrikaDataSet);
            }
            else if (dialogResult == DialogResult.No)
            {

            }
        }

        private void Nayti_Click(object sender, EventArgs e)
        {
            materialyBindingSource.Filter = "[Цена] LIKE'" + tbPoisk.Text + "%'";
        }

        private void Otmena_Click(object sender, EventArgs e)
        {
            materialyBindingSource.Filter = "";
        }

        private void Nazad_Click(object sender, EventArgs e)
        {
            Avtorizatsiya avt = new Avtorizatsiya();
            avt.Show();
            this.Hide();
        }
    }
}

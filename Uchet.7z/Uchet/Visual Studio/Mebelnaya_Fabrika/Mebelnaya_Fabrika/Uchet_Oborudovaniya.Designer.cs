﻿
namespace Mebelnaya_Fabrika
{
    partial class Uchet_Oborudovaniya
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Uchet_Oborudovaniya));
            this.Panel = new System.Windows.Forms.Panel();
            this.Metka_Uchet_Oborudovaniya = new System.Windows.Forms.Label();
            this.Logotip = new System.Windows.Forms.PictureBox();
            this.mebelnaya_FabrikaDataSet = new Mebelnaya_Fabrika.Mebelnaya_FabrikaDataSet();
            this.oborudovanieBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.oborudovanieTableAdapter = new Mebelnaya_Fabrika.Mebelnaya_FabrikaDataSetTableAdapters.OborudovanieTableAdapter();
            this.tableAdapterManager = new Mebelnaya_Fabrika.Mebelnaya_FabrikaDataSetTableAdapters.TableAdapterManager();
            this.oborudovanieDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Udalit = new System.Windows.Forms.Button();
            this.Sohranit = new System.Windows.Forms.Button();
            this.Nazad = new System.Windows.Forms.Button();
            this.Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logotip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mebelnaya_FabrikaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oborudovanieBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oborudovanieDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel
            // 
            this.Panel.BackColor = System.Drawing.SystemColors.GrayText;
            this.Panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel.Controls.Add(this.Metka_Uchet_Oborudovaniya);
            this.Panel.Controls.Add(this.Logotip);
            this.Panel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Panel.ForeColor = System.Drawing.SystemColors.Control;
            this.Panel.Location = new System.Drawing.Point(12, 12);
            this.Panel.Name = "Panel";
            this.Panel.Size = new System.Drawing.Size(730, 102);
            this.Panel.TabIndex = 13;
            // 
            // Metka_Uchet_Oborudovaniya
            // 
            this.Metka_Uchet_Oborudovaniya.AutoSize = true;
            this.Metka_Uchet_Oborudovaniya.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Metka_Uchet_Oborudovaniya.Location = new System.Drawing.Point(262, 38);
            this.Metka_Uchet_Oborudovaniya.Name = "Metka_Uchet_Oborudovaniya";
            this.Metka_Uchet_Oborudovaniya.Size = new System.Drawing.Size(204, 24);
            this.Metka_Uchet_Oborudovaniya.TabIndex = 1;
            this.Metka_Uchet_Oborudovaniya.Text = "Учёт оборудования";
            // 
            // Logotip
            // 
            this.Logotip.Image = ((System.Drawing.Image)(resources.GetObject("Logotip.Image")));
            this.Logotip.Location = new System.Drawing.Point(3, 3);
            this.Logotip.Name = "Logotip";
            this.Logotip.Size = new System.Drawing.Size(97, 94);
            this.Logotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Logotip.TabIndex = 0;
            this.Logotip.TabStop = false;
            // 
            // mebelnaya_FabrikaDataSet
            // 
            this.mebelnaya_FabrikaDataSet.DataSetName = "Mebelnaya_FabrikaDataSet";
            this.mebelnaya_FabrikaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // oborudovanieBindingSource
            // 
            this.oborudovanieBindingSource.DataMember = "Oborudovanie";
            this.oborudovanieBindingSource.DataSource = this.mebelnaya_FabrikaDataSet;
            // 
            // oborudovanieTableAdapter
            // 
            this.oborudovanieTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.FurnituraTableAdapter = null;
            this.tableAdapterManager.MaterialyTableAdapter = null;
            this.tableAdapterManager.OborudovanieTableAdapter = this.oborudovanieTableAdapter;
            this.tableAdapterManager.PolzovateliTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Mebelnaya_Fabrika.Mebelnaya_FabrikaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // oborudovanieDataGridView
            // 
            this.oborudovanieDataGridView.AutoGenerateColumns = false;
            this.oborudovanieDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.oborudovanieDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.oborudovanieDataGridView.DataSource = this.oborudovanieBindingSource;
            this.oborudovanieDataGridView.Location = new System.Drawing.Point(12, 120);
            this.oborudovanieDataGridView.Name = "oborudovanieDataGridView";
            this.oborudovanieDataGridView.Size = new System.Drawing.Size(603, 283);
            this.oborudovanieDataGridView.TabIndex = 14;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Маркировка";
            this.dataGridViewTextBoxColumn1.HeaderText = "Маркировка";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Тип_оборудования";
            this.dataGridViewTextBoxColumn2.HeaderText = "Тип_оборудования";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Характеристики";
            this.dataGridViewTextBoxColumn3.HeaderText = "Характеристики";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Наименование";
            this.dataGridViewTextBoxColumn4.HeaderText = "Наименование";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Дата_покупки";
            this.dataGridViewTextBoxColumn5.HeaderText = "Дата_покупки";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // Udalit
            // 
            this.Udalit.Location = new System.Drawing.Point(621, 165);
            this.Udalit.Name = "Udalit";
            this.Udalit.Size = new System.Drawing.Size(93, 39);
            this.Udalit.TabIndex = 15;
            this.Udalit.Text = "Удалить";
            this.Udalit.UseVisualStyleBackColor = true;
            this.Udalit.Click += new System.EventHandler(this.Udalit_Click);
            // 
            // Sohranit
            // 
            this.Sohranit.Location = new System.Drawing.Point(621, 120);
            this.Sohranit.Name = "Sohranit";
            this.Sohranit.Size = new System.Drawing.Size(93, 39);
            this.Sohranit.TabIndex = 17;
            this.Sohranit.Text = "Сохранить";
            this.Sohranit.UseVisualStyleBackColor = true;
            this.Sohranit.Click += new System.EventHandler(this.Sohranit_Click);
            // 
            // Nazad
            // 
            this.Nazad.Location = new System.Drawing.Point(12, 412);
            this.Nazad.Name = "Nazad";
            this.Nazad.Size = new System.Drawing.Size(93, 39);
            this.Nazad.TabIndex = 18;
            this.Nazad.Text = "Назад";
            this.Nazad.UseVisualStyleBackColor = true;
            this.Nazad.Click += new System.EventHandler(this.Nazad_Click);
            // 
            // Uchet_Oborudovaniya
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 463);
            this.Controls.Add(this.Nazad);
            this.Controls.Add(this.Sohranit);
            this.Controls.Add(this.Udalit);
            this.Controls.Add(this.oborudovanieDataGridView);
            this.Controls.Add(this.Panel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Uchet_Oborudovaniya";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Учёт оборудования";
            this.Load += new System.EventHandler(this.Uchet_Oborudovaniya_Load);
            this.Panel.ResumeLayout(false);
            this.Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logotip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mebelnaya_FabrikaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oborudovanieBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oborudovanieDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Panel;
        private System.Windows.Forms.Label Metka_Uchet_Oborudovaniya;
        private System.Windows.Forms.PictureBox Logotip;
        private Mebelnaya_FabrikaDataSet mebelnaya_FabrikaDataSet;
        private System.Windows.Forms.BindingSource oborudovanieBindingSource;
        private Mebelnaya_FabrikaDataSetTableAdapters.OborudovanieTableAdapter oborudovanieTableAdapter;
        private Mebelnaya_FabrikaDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView oborudovanieDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.Button Udalit;
        private System.Windows.Forms.Button Sohranit;
        private System.Windows.Forms.Button Nazad;
    }
}